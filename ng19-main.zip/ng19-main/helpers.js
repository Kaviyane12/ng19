/* Copyright (C) 2021 THISAN 
Licensed under the  GPL-3.0 License;
you may not use this file except in compliance with the License.
SL-ASIATA THISAN 
*/

function successfullMessage(msg) {
    return "🐼 SL-ASIATA*:  ```" + msg + "```"
}
function errorMessage(msg) {
    return "🐼 SL-ASIATA*:  ```" + msg + "```"
}
function infoMessage(msg) {
    return "🐼 SL-ASIATA*:  ```" + msg + "```"
}


module.exports = {
    successfullMessage,
    errorMessage,
    infoMessage
}
